const { ethers } = require('ethers');
const stakingABI = require('../abi/StakingABI.json');

// Provider and contract instance
const provider = new ethers.providers.JsonRpcProvider(process.env.BLOCKCHAIN_URL);
const contractAddress = process.env.STAKING_CONTRACT_ADDRESS;

const getStakingContract = () => {
    return new ethers.Contract(contractAddress, stakingABI, provider);
};

module.exports = { getStakingContract };