const express = require('express');
const { getStakingContract } = require('../utils/contract');
const { ethers } = require('ethers');
const router = express.Router();

// Fetch staked balance
router.get('/balance/:address', async (req, res) => {
    try {
        const { address } = req.params;
        const contract = getStakingContract();
        const balance = await contract.stakedBalance(address);
        res.json({ stakedBalance: ethers.utils.formatEther(balance) });
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch staked balance' });
    }
});

module.exports = router;